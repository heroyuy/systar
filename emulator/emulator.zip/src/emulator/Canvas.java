package emulator;

import java.awt.Graphics;

import javax.swing.JPanel;

public class Canvas extends JPanel {

    public void paint(Graphics g) {
        super.paint(g);
    }

    public void keyPressed(int key) {
    }

    public void keyReleased(int key) {
    }
}
